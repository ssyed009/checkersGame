// @ts-check
const { test, expect } = require("@playwright/test");

test("Navigate to Checkers site and confirm site is up", async ({ page }) => {
  await page.goto("https://www.gamesforthebrain.com/game/checkers/");

  // Expect a title "to contain" a substring.
  await expect(page).toHaveTitle(/Checkers/);
});

test("Make 5 legal moves", async ({ page }) => {
  await page.goto("https://www.gamesforthebrain.com/game/checkers/");

  // Move 1 - move from poistion 42 to 33.
  await page.locator("css=img[name='space42']").click();
  await page.waitForTimeout(1000);
  await page.locator("css=img[name='space33']").dblclick();
  await page.waitForTimeout(2000);

  // Move 2 - move from poistion 51 to 42.

  await page.locator("css=img[name='space51']").click();
  await page.locator("css=img[name='space42']").click();
  await page.waitForTimeout(3000);

  // Move 3 - move from poistion 02 to 13.

  await page.locator("css=img[name='space02']").click();
  await page.waitForTimeout(1000);
  await page.locator("css=img[name='space13']").dblclick();
  await page.waitForTimeout(3000);

  // Move 4
  // Check if blue peice can be taken -Take a blue piece.

  const element = page.locator("css=img[name='space55']");
  // @ts-ignore
  const outerHTML = await element.evaluate((el) => el.outerHTML);

  // @ts-ignore
  if (expect(outerHTML.includes("gray.gif"))) {
    await page.locator("css=img[name='space33']").click();
    await page.waitForTimeout(1000);
    await page.locator("css=img[name='space55']").click();
    await page.waitForTimeout(3000);
  }

  // Move 5 - check for 'Make a Move' text before making next move.

  // Wait for 5 seconds
  await page.waitForTimeout(5000);

  const message = page.locator("css=#message");
  const moveText = await message.textContent();

  // @ts-ignore
  if ((expect(moveText == "Make a move."), "User is not allowed to move")) {
    await page.locator("css=img[name='space40']").click();
    await page.waitForTimeout(1000);
    await page.locator("css=img[name='space51']").click();
    await page.waitForTimeout(3000);
  }

  // Restart after 5 moves and Confirm that the restarting had been successful.

  await page.locator("//a[normalize-space()='Restart...']").click();
  await page.waitForTimeout(1000);
  const restartText = await message.textContent();
  expect(
    restartText == "Select an orange piece to move.",
    "Restart was not successful"
  );
});
